export const TAB_VALUES = {
	LOGIN: 'login',
	REGISTER: 'register',
} as const
