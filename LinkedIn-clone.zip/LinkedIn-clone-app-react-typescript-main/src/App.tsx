import RouteLayout from './Routes'

function App() {
	return <RouteLayout />
}

export default App
