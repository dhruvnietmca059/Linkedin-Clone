export type ChatT = {
	name: string
	photoUrl: string
	lastMessage: string
	lastMessageTime: string
	id: number
}
